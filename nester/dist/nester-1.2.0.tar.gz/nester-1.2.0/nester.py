#输出当前列表以及内部列表的所有元素
def is_list(list_, indent=False, level=0):
    for each_item in list_:
        if isinstance(each_item, list):
            is_list(each_item, level + 1)
        else:
            if indent:
                for tap_stop in range(level):
                    print('\t', end='')
            print(each_item)


def split_lint(num=0, msg=''):
    print('-' * int(num / 2) + msg + '-' * int(num / 2))
