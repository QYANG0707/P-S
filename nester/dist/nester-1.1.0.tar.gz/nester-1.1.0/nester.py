#输出当前列表以及内部列表的所有元素
def is_list(list_, level):
    for each_item in list_:
        if isinstance(each_item, list):
            is_list(each_item, level + 1)
        else:
            for tap_stop in range(level):
                print('\t', end='')
            print(each_item)
